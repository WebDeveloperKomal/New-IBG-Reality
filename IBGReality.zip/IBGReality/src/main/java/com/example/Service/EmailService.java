package com.example.Service;

public interface EmailService {

	 void sendThankYouEmail(String to, String subject, String text);
}
