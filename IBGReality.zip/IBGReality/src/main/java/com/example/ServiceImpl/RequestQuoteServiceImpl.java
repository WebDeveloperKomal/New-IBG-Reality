package com.example.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Entity.RequestQuote;
import com.example.Repository.RequestQuoteRepository;
import com.example.Service.EmailService;
import com.example.Service.RequestQuoteService;

@Service
public class RequestQuoteServiceImpl implements RequestQuoteService {
	
	@Autowired
	private RequestQuoteRepository requestQuoteRepository;
	
	@Autowired
	private EmailService emailService;

	@Override
	public RequestQuote saveRequestQuote(RequestQuote requestQuote) {
		  RequestQuote savedQuote = requestQuoteRepository.save(requestQuote);
	        
	        // Send thank you email
	        emailService.sendThankYouEmail(
	            savedQuote.getEmail(), 
	            "Thank you for your inquiry", 
	            "Dear " + savedQuote.getCompanyName() + ",\n\nThank you for contacting us. We will get back to you shortly.\n\nBest regards,\nIBG Reality"
	        );
	        return savedQuote;
	}

	@Override
	public List<RequestQuote> getAllQuotesList() {
		// TODO Auto-generated method stub
		return requestQuoteRepository.getAll();
	}

	@Override
	public RequestQuote getRequestQuoteById(int id) {
		// TODO Auto-generated method stub
		return requestQuoteRepository.findById(id);
	}

	@Override
	public RequestQuote deleteRequestQuoteById(int id) {
		// TODO Auto-generated method stub
		RequestQuote requestQuote = requestQuoteRepository.findById(id);
		requestQuote.setDeleted(true);
		return requestQuoteRepository.save(requestQuote);
	}

	@Override
	public RequestQuote updateRequestQuoteById(RequestQuote requestQuote, int id) {
		// TODO Auto-generated method stub
		requestQuote.setId(id);
		return requestQuoteRepository.save(requestQuote);
	}

}
